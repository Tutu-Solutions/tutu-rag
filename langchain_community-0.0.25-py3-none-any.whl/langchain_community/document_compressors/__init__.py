from langchain_community.document_compressors.llmlingua_filter import (
    LLMLinguaCompressor,
)

__all__ = [
    "LLMLinguaCompressor",
]
